package nebulous.main;

public class ItemStack {
	
	private Item item;
	private int count;

	public ItemStack(Item item, int count) {
		this.item = item;
		this.count = count;
	}
	
	public boolean increase(int ammount){
		if(count + ammount > item.getMaxStackSize()){
			System.err.println("Error increasing stack, exceded max stack size." + 
					"[" + getItem().getName() + "(" + ammount + ")" +  "]");
			return false;
		}
		else count += ammount;
		return true;
	}
	
	public boolean decrease(int ammount){
		if(count - ammount < 0){
			System.err.println("Error decreasing stack, cannot decrease below zero." + 
					"[" + getItem().getName() + "(" + ammount + ")" +  "]");
			return false;
		}
		else count -= ammount;
		if(count == 0) clearStack();
		return true;
	}
	
	public void clearStack(){
		count = 0;
		item = null;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
