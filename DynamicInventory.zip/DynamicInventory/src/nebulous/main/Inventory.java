package nebulous.main;

public class Inventory {
	
	private Slot[] slots;
	private int size;
	private int width = 6;
	private int height = 128;
	
	public Inventory(int size){
		this.size = size;
		slots = new Slot[size];
		for(int i = 0; i < size; i++)
			slots[i] = new Slot(i);
	}
	
	public Inventory(int width, int height){
		this.size = width * height;
		this.width = width;
		this.height = height;
		slots = new Slot[size];
		for(int i = 0; i < size; i++)
			slots[i] = new Slot(i);
	}
	
	public void printInventory(){
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				ItemStack stack = slots[x + y * height].getItemStack();
				if(stack.getItem() == null){
					System.out.print("[(" + stack.getCount() + ")" + "NONE" + "]");
				} else {
					System.out.print("[(" + stack.getCount() + ")" + stack.getItem().getName() + "]");
				}
			} System.out.print("\n");
		}
	}
	
	public void addItem(Item item, int count){
		for(int i = 0; i < slots.length; i++){
			if(slots[i].getItemStack().getItem() == null){
				slots[i].setItemStack(new ItemStack(item, count));
				break;
			} else if(slots[i].getItemStack().getItem().equals(item)){
				slots[i].getItemStack().increase(count);
				break;
			} else if(slots[i].getItemStack().getItem() != null){
				continue;
			} else {
				System.err.println("Error adding Item" + item.getName() + ", No available slots in inventory");
			} 
		}
	}
	
	public void placeItem(Item item, int count, int slot){
		ItemStack stack = new ItemStack(item, 0);
		if(stack.increase(count) == true)
			slots[slot].setItemStack(stack);
	}
	
	public void placeItem(Item item, int count, int x, int y){
		ItemStack stack = new ItemStack(item, 0);
		if(stack.increase(count) == true)
			slots[x + y * height].setItemStack(stack);
	}
	
	public Slot getSlot(int id){
		return slots[id];
	}
	
	public Slot getSlots(int x, int y){
		return slots[x * y + height];
	}
	
	public Item getItemInSlot(int id){
		return slots[id].getItemStack().getItem();
	}
	
	public Item getItemInSlot(int x, int y){
		return slots[x * y + height].getItemStack().getItem();
	}
	
	public ItemStack getItemStackInSlot(int id){
		return slots[id].getItemStack();
	}
	
	public ItemStack getItemStackInSlot(int x, int y){
		return slots[x * y + height].getItemStack();
	}

	public Slot[] getSlots() {
		return slots;
	}

	public int getSize() {
		return size;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
}
