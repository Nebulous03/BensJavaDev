package nebulous.main;

import nebulous.items.IronSword;

public class MainClass {
	
	public static void main(String[] args){
		Inventory inventory = new Inventory(12, 12);
		inventory.addItem(new IronSword(), 2);
//		inventory.addItem(new Item("Sword"), 2);
//		inventory.addItem(new Item("Dagger"), 3);
//		inventory.placeItem(new Item("Computer"), 128, 9, 9);
		inventory.printInventory();
	}

}
