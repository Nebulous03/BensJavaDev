package nebulous.main;

public class Inventory {
	
	private Slot[] slots;
	private int size;
	private int width = 6;
	private int height = 128;
	
	public Inventory(int size){
		this.size = size;
		slots = new Slot[size];
		for(int i = 0; i < size; i++)
			slots[i] = new Slot(i);
	}
	
	public Inventory(int width, int height){
		this.size = width * height;
		this.width = width;
		this.height = height;
		slots = new Slot[size];
		for(int i = 0; i < size; i++)
			slots[i] = new Slot(i);
	}
	
	public void printInventory(){
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				ItemStack stack = slots[x + y * height].getItemStack();
				if(stack.getItem() == null){
					System.out.print("[(" + stack.getCount() + ")" + "NONE" + "]");
				} else {
					System.out.print("[(" + stack.getCount() + ")" + stack.getItem().getName() + "]");
				}
			} System.out.print("\n");
		}
	}
	
	public void addItem(Item item, int count){
		for(int i = 0; i < slots.length; i++){
			ItemStack stack = slots[i].getItemStack();
			if(stack.getItem() == null){ 
				stack.setItem(item);
				if(!slots[i].getItemStack().increase(count))
					stack.setItem(null);
				break;
			} else if(stack.getItem().equals(item)){
				if(stack.getCount() + count < item.getMaxStackSize() + 1)
					stack.increase(count);
				else continue;
				break;
			} else if(stack.getItem() != null){
				continue;
			} else {
				System.err.println("Error adding item [" + "(" + count + ")" + item.getName() + "], no available slots in inventory");
			} 
		}
	}
	
	public void addItem(Item item, int count, int slot){
		ItemStack stack = slots[slot].getItemStack();
		if(stack.getItem() == null){ 
			stack.setItem(item);
			if(!slots[slot].getItemStack().increase(count))
				stack.setItem(null);
		} else if(stack.getItem().equals(item)){
			if(stack.getCount() + count < item.getMaxStackSize() + 1)
				stack.increase(count);
		} else if(stack.getItem() != null){
			System.err.println("Error adding item [" + "(" + count + ")" + item.getName() + "] in slot " + slot + 
					", slot already contains [" + "(" + stack.getCount() + ")" +  stack.getItem().getName() + "].");
		} else {
			System.err.println("Error adding item [" + "(" + count + ")" + item.getName() + "], no available slots in inventory");
		} 
	}
	
	public void addItem(Item item, int count, int x, int y){
		addItem(item, count, x + y * height);
	}
	
	public void addItem(Item item, int count, int slot, boolean force){
		if(force){
			ItemStack stack = new ItemStack(item, count);
			slots[slot].setItemStack(stack);
		} else {
			addItem(item, count, slot);
		}
	}
	
	public void addItem(Item item, int count, int x, int y, boolean force){
		if(force){
			ItemStack stack = new ItemStack(item, count);
			slots[x + y * height].setItemStack(stack);
		} else {
			addItem(item, count, x, y);
		}
	}
	
	public Slot getSlot(int id){
		return slots[id];
	}
	
	public Slot getSlots(int x, int y){
		return slots[x * y + height];
	}
	
	public Item getItemInSlot(int id){
		return slots[id].getItemStack().getItem();
	}
	
	public Item getItemInSlot(int x, int y){
		return slots[x * y + height].getItemStack().getItem();
	}
	
	public ItemStack getItemStackInSlot(int id){
		return slots[id].getItemStack();
	}
	
	public ItemStack getItemStackInSlot(int x, int y){
		return slots[x * y + height].getItemStack();
	}

	public Slot[] getSlots() {
		return slots;
	}

	public int getSize() {
		return size;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
}
